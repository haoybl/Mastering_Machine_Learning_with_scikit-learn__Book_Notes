__author__ = 'gavin'

#use sgdclassifier with log loss
# http://www.kaggle.com/c/facebook-recruiting-iii-keyword-extraction/forums/t/6650/share-your-approach

