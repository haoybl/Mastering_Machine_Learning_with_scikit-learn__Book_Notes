import glob
import numpy as np
import mahotas as mh
from sklearn.cross_validation import train_test_split
from sklearn.metrics import classification_report
from sklearn.decomposition import PCA
from sklearn.linear_model import LogisticRegression
from os import walk
from sklearn.preprocessing import scale
import os

print 'Loading the images...'
# TODO change path
X = []
y = []
for (dirpath, dirnames, filenames) in walk('/home/gavin/PycharmProjects/mastering-machine-learning/ch-reduction/data/faces94/male'):
    for fn in filenames:
        if fn[-3:] == 'jpg':
            image_filename = os.path.join(dirpath, fn)
            X.append(scale(mh.imread(image_filename, as_grey=True).reshape(36000)))
            y.append(fn[:fn.index('.')])

X = np.array(X)
X_train, X_test, y_train, y_test = train_test_split(X, y)

n_components = 150
print 'Reducing the dimensions...'
pca = PCA(n_components=n_components)
X_train_reduced = pca.fit_transform(X_train)
X_test_reduced = pca.transform(X_test)
print X_train_reduced.shape
print X_test_reduced.shape

print 'Training the classifier...'
classifier = LogisticRegression()
classifier.fit_transform(X_train_reduced, y_train)
print classifier.score(X_test_reduced, y_test)
predictions = classifier.predict(X_test_reduced)
print classification_report(y_test, predictions)

for i, p in enumerate(predictions):
    print p, y_test[i]